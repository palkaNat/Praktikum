/*
 * ===========================================================================
 *
 * tsh.cpp --
 *
 * ===========================================================================
 */


#include "makeargv.h"

#include <vector>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <sys/wait.h>
#include <errno.h>

// maximal length of user input
#define MAX_COMMAND_LINE_LENGTH 1024





/* type definitions **************************************************************/

// constants for job status
typedef enum {
  JOB_RUNNING, JOB_FINISHED
} job_status_t;

// job descriptor
typedef struct {
  char* command;            // c-string containing the original command
  int internal_id;          // job id (shell-internal)
  int pid;                  // process id of the job (from OS)
  int exit_status;          // exit status of the job
  job_status_t job_status;  // status of the job
} job_descr_t;


/* global variables **************************************************************/

// list of all jobs ever started in the shell;
// list elements are POINTERS to job descriptors
static std::vector<job_descr_t*> job_list;
static int intern_id=0;




/* functions ********************************************************************/
void job_add(char **argv, int argc, int exit_status, int cpid, job_status_t status){
	char *cmd=(char*)malloc(sizeof(argv)/sizeof(char));
	
	for (int i=0; i<argc; i++){
	
	strcat(cmd,argv[i]); //kommando in einen String verketten
	strcat(cmd," ");
	}
	
	job_descr_t *job =new job_descr_t; //struct als pointer
	
	
	//job initialisieren
	job->command = cmd;
	job->internal_id = intern_id;
	job->pid =cpid;
	job->exit_status=exit_status;
	job->job_status=status;
	intern_id++;
	
	job_list.push_back(job); //job an Liste dran hängen
	
}
//hole den Job aus der Liste
job_descr_t* get_job(int id){

	for(int i=0; i<(int)job_list.size(); i++){
		if (job_list[i]->internal_id== id){
			return job_list[i];	
		}	
	}
	printf("[Job not found]\n");
	return NULL;
}

void job_wait(int id){
	job_descr_t* job = get_job(id);
	
	int pid=job->pid;
	int status =job->exit_status;
	
		
	waitpid(pid,&status,0);
	status=WEXITSTATUS(status);
	job->exit_status=status;
	job->job_status= JOB_FINISHED;

}

void job_kill(int id){
	
	job_descr_t* job_total=get_job(id);
	if (job_total!= NULL){
		int exit_status=job_total->exit_status;
		int pid = job_total->pid;	
		kill(pid,SIGKILL);
		waitpid(pid, &exit_status,0);
		job_total->job_status=JOB_FINISHED;
		job_total->exit_status=-1;
	}

}



void info(int input_id){


	job_descr_t* job_get = get_job(input_id);
	
	if(job_get!=NULL)
	{
	char *cmd= job_get->command;
	int id= job_get->internal_id;
	int pid=job_get->pid;
	job_status_t job_status = job_get->job_status; 
	int exit_status=job_get->exit_status;
	if(waitpid(pid,&exit_status,WNOHANG))
		{
			if (job_status == JOB_RUNNING){
				
				exit_status=WEXITSTATUS(exit_status);
				job_status=JOB_FINISHED;
				job_get->exit_status=exit_status;
				job_get->job_status=job_status;
			}
		}		
	printf("%i (pid\t%i %s status = %i): %s\n", id,pid, (job_status==JOB_RUNNING)?"running":"finished",exit_status,cmd);
	}
	
}
void foreground_job(char **argv, int argc){
	int exit_status;
	int cpid = fork();//ID des auggerufenes Processes
	if (cpid==0){
	
	
	execvp(argv[0],argv);//commando wird übergeben
	printf("[command not found]\n");
	exit_status= 255;
	printf("[status=%i]\n", exit_status);
	exit(exit_status);
	}
	else{
	waitpid(cpid, &exit_status,0); //wartet bis Kind zurückkehrt
	exit_status=WEXITSTATUS(exit_status);
	
	job_add(argv,argc, exit_status,cpid,JOB_FINISHED);
	}
}

void background_job(char **argv, int argc){

	
	int cpid = fork();//ID des auggerufenes Processes
	if (cpid==0){
	
	close(1); //Standardausgabe schließen
	execvp(argv[0],argv);//commando wird übergeben
	printf("[command not found]\n");
	}
	else{

	int exit_status= 0;
	job_status_t status=JOB_RUNNING;
	job_add(argv, argc,exit_status, cpid,status);
	}
	
}


void show_list(){

	for (int i=0; i<job_list.size(); i++){
		job_descr_t*  job = job_list[i];
		char *cmd= job->command;
		int id= job->internal_id;
		int pid=job->pid;
		int exit_status=job->exit_status;
		job_status_t job_status = job->job_status; 
		if(waitpid(pid,&exit_status,WNOHANG))
		{
			if (job_status == JOB_RUNNING){
				
				exit_status=WEXITSTATUS(exit_status);
				job_status=JOB_FINISHED;
				job->exit_status=exit_status;
				job->job_status=job_status;
			}
		}		
		printf("%i (pid\t%i %s status = %i): %s\n", id,pid,(job_status==JOB_RUNNING)?"running":"finished",exit_status,cmd);
		
	}
}
// function for the processing of the user input;
// shows prompt and waits for user input;
// user input is parsed and appropriate action is taken...
void tsh_prompt_and_process()
{
  // buffer for user input
  static char buffer[MAX_COMMAND_LINE_LENGTH+1];

  char** argv_intern = NULL;  // holds the user input after separation into tokens
  int numtokens = 0;          // number of tokens

  // show prompt and wait for user input
  printf( "tsh> " ); fflush( stdout );
  fgets( buffer, MAX_COMMAND_LINE_LENGTH, stdin );
  
  // separate char string in buffer (user input) into single tokens
  numtokens = makeargv( buffer, " \n", &argv_intern );

  // ======================================================================
  // BEGIN: HERE GOES YOUR CODE! 
  // ======================================================================
  
  // TODO: REMOVE THIS FOR LOOP AFTER YOUR SOLUTION IS FINISHED
  /*for( int i=0; i < numtokens; i++ ) {
    printf( "%s\n", argv_intern[i] );
  }*/

  // check if at least one token was entered at the command line
  // (if not: do nothing)
  if( numtokens > 0 )
  {
      if( strcmp( "quit", argv_intern[0] ) == 0 )
      {
          // leave tsh          
          _exit( 0 );
      }
      else if( strcmp( "info", argv_intern[0] ) == 0 )
      {
          // TODO: Here goes your code for the info command
          // (good idea: put it into an extra function)
          if (numtokens>1)
          info (atoi(argv_intern[1]));
      }
      else if( strcmp( "list", argv_intern[0] ) == 0 )
      {
          // TODO: Here goes your code for the list command
          // (good idea: put it into an extra function)
          show_list();
      }
      else if( strcmp( "wait", argv_intern[0] ) == 0 )
      {
          // TODO: Here goes your code for the wait command
          // (good idea: put it into an extra function)
           if (numtokens>1)
           job_wait(atoi(argv_intern[1]));
      }
      else if( strcmp( "kill", argv_intern[0] ) == 0 )
      {
          // TODO: Here goes your code for the kill command
          // (good idea: put it into an extra function)
           if (numtokens>1)
          job_kill(atoi(argv_intern[1]));
      }
      else if( strcmp( "job", argv_intern[0] ) == 0 )
      {
          // TODO: Here goes your code for the job command
          // (good idea: put it into an extra function)
          char **job;
          job=argv_intern+1; //um job commando zu unterdrücken
          background_job(job, numtokens-1);
      }
      else
      {
          // TODO: Here goes the code to start a foreground job
          // (good idea: put it into an extra function)
	         
          //Ausführen externe Kommandos
          foreground_job(argv_intern, numtokens);
          
       
         
      }
  }

  // ======================================================================
  // END: HERE GOES YOUR CODE! 
  // ======================================================================
  
  // clean up
  if( argv_intern )
    freemakeargv( argv_intern );

  return;
}



/* main **************************************************************************/

int
main( int argc, char **argv )
{

  
  // init lists
  job_list.resize(0);
  

  // main loop
  while( 1 ) {
    // process user input
    tsh_prompt_and_process();
  }
  
  
  

  _exit( 0 );
}

